/*!
<div align="center">
    <img src="https://raw.githubusercontent.com/litesvm/litesvm/master/logo.jpeg" width="50%" height="50%">
</div>

---

# LiteSVM

[<img alt="github" src="https://img.shields.io/badge/github-LiteSVM/litesvm-8da0cb?style=for-the-badge&labelColor=555555&logo=github" height="20">](https://github.com/LiteSVM/litesvm)
[<img alt="crates.io" src="https://img.shields.io/crates/v/litesvm.svg?style=for-the-badge&color=fc8d62&logo=rust" height="20">](https://crates.io/crates/litesvm)
[<img alt="docs.rs" src="https://img.shields.io/badge/docs.rs-litesvm-66c2a5?style=for-the-badge&labelColor=555555&logo=docs.rs" height="20">](https://docs.rs/litesvm/latest/litesvm/)
[<img alt="build status" src="https://img.shields.io/github/actions/workflow/status/LiteSVM/litesvm/CI.yml?branch=master&style=for-the-badge" height="20">](https://github.com/LiteSVM/litesvm/actions?query=branch%3Amaster)

## 📍 Overview

`litesvm` is a fast and lightweight library for testing Solana programs.
It works by creating an in-process Solana VM optimized for program developers.
This makes it much faster to run and compile than alternatives like `solana-program-test` and `solana-test-validator`.
In a further break from tradition, it has an ergonomic API with sane defaults and extensive configurability for those who want it.

### 🤖 Minimal Example

```rust
use litesvm::LiteSVM;
use solana_address::Address;
use solana_message::Message;
use solana_system_interface::instruction::transfer;
use solana_keypair::Keypair;
use solana_signer::Signer;
use solana_transaction::Transaction;

let from_keypair = Keypair::new();
let from = from_keypair.pubkey();
let to = Address::new_unique();

let mut svm = LiteSVM::new();
svm.airdrop(&from, 1_000_000_000).unwrap();
svm.airdrop(&to, 1_000_000_000).unwrap();

let instruction = transfer(&from, &to, 64);
let tx = Transaction::new(
    &[&from_keypair],
    Message::new(&[instruction], Some(&from)),
    svm.latest_blockhash(),
);
let tx_res = svm.send_transaction(tx).unwrap();

let from_account = svm.get_account(&from);
let to_account = svm.get_account(&to);
assert_eq!(from_account.unwrap().lamports, 999994936);
assert_eq!(to_account.unwrap().lamports, 1000000064);
```

## Deploying Programs

Most of the time we want to do more than just mess around with token transfers -
we want to test our own programs.

**Tip**: if you want to pull a Solana program from mainnet or devnet, use the `solana program dump` command from the Solana CLI.

To add a compiled program to our tests we can use [`.add_program_from_file`](LiteSVM::add_program_from_file).

Here's an example using a [simple program](https://github.com/solana-labs/solana-program-library/tree/bd216c8103cd8eb9f5f32e742973e7afb52f3b81/examples/rust/logging)
from the Solana Program Library that just does some logging:

```rust
use {
    litesvm::LiteSVM,
    solana_address::{address, Address},
    solana_instruction::{account_meta::AccountMeta, Instruction},
    solana_keypair::Keypair,
    solana_message::{Message, VersionedMessage},
    solana_signer::Signer,
    solana_transaction::versioned::VersionedTransaction,
};

fn test_logging() {
    let program_id = address!("Logging111111111111111111111111111111111111");
    let account_meta = AccountMeta {
        pubkey: Address::new_unique(),
        is_signer: false,
        is_writable: true,
    };
    let ix = Instruction {
        program_id,
        accounts: vec![account_meta],
        data: vec![5, 10, 11, 12, 13, 14],
    };
    let mut svm = LiteSVM::new();
    let payer = Keypair::new();
    let bytes = include_bytes!("../../node-litesvm/program_bytes/spl_example_logging.so");
    svm.add_program(program_id, bytes);
    svm.airdrop(&payer.pubkey(), 1_000_000_000).unwrap();
    let blockhash = svm.latest_blockhash();
    let msg = Message::new_with_blockhash(&[ix], Some(&payer.pubkey()), &blockhash);
    let tx = VersionedTransaction::try_new(VersionedMessage::Legacy(msg), &[payer]).unwrap();
    // let's sim it first
    let sim_res = svm.simulate_transaction(tx.clone()).unwrap();
    let meta = svm.send_transaction(tx).unwrap();
    assert_eq!(sim_res.meta, meta);
    assert_eq!(meta.logs[1], "Program log: static string");
    assert!(meta.compute_units_consumed < 10_000) // not being precise here in case it changes
}

```

## Time travel

Many programs rely on the `Clock` sysvar: for example, a mint that doesn't become available until after
a certain time. With `litesvm` you can dynamically overwrite the `Clock` sysvar
using [`svm.set_sysvar::<Clock>()`](LiteSVM::set_sysvar).
Here's an example using a program that panics if `clock.unix_timestamp` is greater than 100
(which is on January 1st 1970):

```rust
use {
    litesvm::LiteSVM,
    solana_address::Address,
    solana_clock::Clock,
    solana_instruction::Instruction,
    solana_keypair::Keypair,
    solana_message::{Message, VersionedMessage},
    solana_signer::Signer,
    solana_transaction::versioned::VersionedTransaction,
};

fn test_set_clock() {
    let program_id = Address::new_unique();
    let mut svm = LiteSVM::new();
    let bytes = include_bytes!("../../node-litesvm/program_bytes/litesvm_clock_example.so");
    svm.add_program(program_id, bytes);
    let payer = Keypair::new();
    let payer_address = payer.pubkey();
    svm.airdrop(&payer.pubkey(), 1_000_000_000).unwrap();
    let blockhash = svm.latest_blockhash();
    let ixs = [Instruction {
        program_id,
        data: vec![],
        accounts: vec![],
    }];
    let msg = Message::new_with_blockhash(&ixs, Some(&payer_address), &blockhash);
    let versioned_msg = VersionedMessage::Legacy(msg);
    let tx = VersionedTransaction::try_new(versioned_msg, &[&payer]).unwrap();
    // set the time to January 1st 2000
    let mut initial_clock = svm.get_sysvar::<Clock>();
    initial_clock.unix_timestamp = 1735689600;
    svm.set_sysvar::<Clock>(&initial_clock);
    // this will fail because it's not January 1970 anymore
    svm.send_transaction(tx).unwrap_err();
    // so let's turn back time
    let mut clock = svm.get_sysvar::<Clock>();
    clock.unix_timestamp = 50;
    svm.set_sysvar::<Clock>(&clock);
    let ixs2 = [Instruction {
        program_id,
        data: vec![1], // unused, this is just to dedup the transaction
        accounts: vec![],
    }];
    let msg2 = Message::new_with_blockhash(&ixs2, Some(&payer_address), &blockhash);
    let versioned_msg2 = VersionedMessage::Legacy(msg2);
    let tx2 = VersionedTransaction::try_new(versioned_msg2, &[&payer]).unwrap();
    // now the transaction goes through
    svm.send_transaction(tx2).unwrap();
}

```

See also: [`warp_to_slot`](LiteSVM::warp_to_slot), which lets you jump to a future slot.

## Writing arbitrary accounts

LiteSVM lets you write any account data you want, regardless of
whether the account state would even be possible.

Here's an example where we give an account a bunch of USDC,
even though we don't have the USDC mint keypair. This is
convenient for testing because it means we don't have to
work with fake USDC in our tests:

```rust
use {
    litesvm::LiteSVM,
    solana_account::Account,
    solana_address::{address, Address},
    solana_program_option::COption,
    solana_program_pack::Pack,
    spl_associated_token_account_interface::address::get_associated_token_address,
    spl_token_interface::{
        state::{Account as TokenAccount, AccountState},
        ID as TOKEN_PROGRAM_ID,
    },
};

fn test_infinite_usdc_mint() {
    let owner = Address::new_unique();
    let usdc_mint = address!("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v");
    let ata = get_associated_token_address(&owner, &usdc_mint);
    let usdc_to_own = 1_000_000_000_000;
    let token_acc = TokenAccount {
        mint: usdc_mint,
        owner: owner,
        amount: usdc_to_own,
        delegate: COption::None,
        state: AccountState::Initialized,
        is_native: COption::None,
        delegated_amount: 0,
        close_authority: COption::None,
    };
    let mut svm = LiteSVM::new();
    let mut token_acc_bytes = [0u8; TokenAccount::LEN];
    TokenAccount::pack(token_acc, &mut token_acc_bytes).unwrap();
    svm.set_account(
        ata,
        Account {
            lamports: 1_000_000_000,
            data: token_acc_bytes.to_vec(),
            owner: TOKEN_PROGRAM_ID,
            executable: false,
            rent_epoch: 0,
        },
    )
    .unwrap();
    let raw_account = svm.get_account(&ata).unwrap();
    assert_eq!(
        TokenAccount::unpack(&raw_account.data).unwrap().amount,
        usdc_to_own
    )
}

```

## Copying Accounts from a live environment

If you want to copy accounts from mainnet or devnet, you can use the `solana account` command in the Solana CLI to save account data to a file.

## Register tracing

`litesvm` can be instantiated with the capability to provide register tracing
data from processed transactions. This functionality is gated behind the
`register-tracing` feature flag, which in turn relies on the
`invocation-inspect-callback` flag. To enable it, users can either
construct `litesvm` with the `LiteSVM::new_debuggable` initializer - allowing
register tracing to be configured directly - or simply set the `SBF_TRACE_DIR`
environment variable, which `litesvm` interprets as a signal to turn tracing on
upon instantiation. The latter allows users to take advantage of the
functionality without actually doing any changes to their code.

A default post-instruction callback is provided for storing the
register tracing data in files. It persists the register sets,
the SBPF instructions, and a SHA-256 hash identifying the executable that
was used to generate the tracing data. If the `SBF_TRACE_DISASSEMBLE`
environment variable is set, a disassembled register trace will also be
produced for each collected register trace. The motivation behind providing the
SHA-256 identifier is that files may grow in number, and consumers need a
deterministic way to evaluate which shared object should be used when
analyzing the tracing data.

When the `sbpf-debugger` feature is enabled and `SBF_DEBUG_PORT` is set, the
VM will start a GDB remote stub on the specified TCP port. A debugger client
can then connect to inspect registers, memory, set
breakpoints, and step through SBPF execution.

The `SBF_TRACE_FILTER` environment variable can be used to narrow which
traces are collected and what is going to be debugged. It supports filtering
by `txsig` and `program_id` with the `==`, `!=`, `||`, and `&&` operators.
For example: `SBF_TRACE_FILTER="txsig == A && (program_id == B || program_id == C)"`.

Once enabled register tracing can't be changed afterwards because in nature
it's baked into the program executables at load time. Yet a user may want a
more fine-grained control over when register tracing data should be
collected - for example, only for a specific instruction. Such control could
be achieved by resetting the invocation callback to
`EmptyInvocationInspectCallback` and later by restoring it to
`DefaultRegisterTracingCallback`.

## Other features

Other things you can do with `litesvm` include:

* Changing the max compute units and other compute budget behaviour using [`.with_compute_budget`](LiteSVM::with_compute_budget).
* Disable transaction signature checking using [`.with_sigverify(false)`](LiteSVM::with_sigverify).
* Find previous transactions using [`.get_transaction`](`LiteSVM::get_transaction`).

## Feature Flags

| Feature | Description |
|---|---|
| `precompiles` | Loads the standard precompiles (ed25519, secp256k1) alongside the builtins. Enables [`with_precompiles`](LiteSVM::with_precompiles). |
| `invocation-inspect-callback` | Enables the [`InvocationInspectCallback`] trait and [`set_invocation_inspect_callback`](LiteSVM::set_invocation_inspect_callback), giving low-level access to the `InvokeContext` before and after each transaction. |
| `register-tracing` | Enables BPF register-level tracing. Implies `invocation-inspect-callback`. See [`LiteSVM::new_debuggable`] and [`register_tracing::DefaultRegisterTracingCallback`]. |
| `hashbrown` | Switches internal hash maps to `hashbrown`. |
| `serde` | Enables serde serialization/deserialization on internal types. |
| `nodejs-internal` | Used by the Node.js bindings; not intended for direct use. |

## When should I use `solana-test-validator`?

While `litesvm` is faster and more convenient, it is also less like a real RPC node.
So `solana-test-validator` is still useful when you need to call RPC methods that LiteSVM
doesn't support, or when you want to test something that depends on real-life validator behaviour
rather than just testing your program and client code.

In general though it is recommended to use `litesvm` wherever possible, as it will make your life
much easier.

*/

#![cfg_attr(docsrs, feature(doc_cfg))]

#[cfg(feature = "register-tracing")]
use crate::register_tracing::DefaultRegisterTracingCallback;
#[cfg(feature = "hashbrown")]
use hashbrown::{hash_map::Entry, HashMap};
#[cfg(feature = "persistence-internal")]
use indexmap::IndexMap;
#[cfg(feature = "precompiles")]
use precompiles::load_precompiles;
#[cfg(feature = "nodejs-internal")]
use qualifier_attr::qualifiers;
#[allow(deprecated)]
use solana_sysvar::recent_blockhashes::IterItem;
#[allow(deprecated)]
use solana_sysvar::{fees::Fees, recent_blockhashes::RecentBlockhashes};
#[cfg(not(feature = "hashbrown"))]
use std::collections::{hash_map::Entry, HashMap};
use {
    crate::{
        accounts_db::{load_preverified, visible_deployment_slot, AccountsDb},
        error::LiteSVMError,
        features::MAINNET_ACTIVE_FEATURES,
        history::TransactionHistory,
        programs::load_default_programs,
        types::{
            ExecutionResult, FailedTransactionMetadata, TransactionMetadata, TransactionResult,
        },
        utils::{
            create_blockhash,
            rent::{check_rent_state_with_account, RentStateInfo},
            LoadedTransactionDataSize, ADDRESS_LOOKUP_TABLE_BASE_SIZE,
            TRANSACTION_ACCOUNT_BASE_SIZE,
        },
    },
    agave_feature_set::{raise_cpi_nesting_limit_to_8, FeatureSet},
    agave_reserved_account_keys::ReservedAccountKeys,
    log::error,
    solana_account::{Account, AccountSharedData, ReadableAccount, WritableAccount},
    solana_address::Address,
    solana_builtins::BUILTINS,
    solana_clock::Clock,
    solana_compute_budget::compute_budget::ComputeBudget,
    solana_epoch_rewards::EpochRewards,
    solana_epoch_schedule::EpochSchedule,
    solana_feature_gate_interface::{self as feature_gate, Feature},
    solana_fee::FeeFeatures,
    solana_fee_structure::FeeStructure,
    solana_hash::Hash,
    solana_keypair::Keypair,
    solana_last_restart_slot::LastRestartSlot,
    solana_loader_v3_interface::state::UpgradeableLoaderState,
    solana_message::{
        inner_instruction::InnerInstructionsList, Message, SanitizedMessage, VersionedMessage,
    },
    solana_native_token::LAMPORTS_PER_SOL,
    solana_nonce::{state::DurableNonce, NONCED_TX_MARKER_IX_INDEX},
    solana_program_runtime::{
        invoke_context::{BuiltinFunctionRegisterer, EnvironmentConfig, InvokeContext},
        loaded_programs::{ProgramRuntimeEnvironment, ProgramRuntimeEnvironments},
        program_cache_entry::ProgramCacheEntry,
        program_metrics::LoadProgramMetrics,
        solana_sbpf::program::BuiltinProgram,
    },
    solana_rent::Rent,
    solana_runtime_transaction::transaction_meta::TransactionConfiguration,
    solana_sdk_ids::{
        bpf_loader, bpf_loader_deprecated, bpf_loader_upgradeable, config as config_program,
        native_loader, system_program,
    },
    solana_signature::Signature,
    solana_signer::Signer,
    solana_slot_hashes::SlotHashes,
    solana_slot_history::SlotHistory,
    solana_stake_history::StakeHistory,
    solana_svm_log_collector::LogCollector,
    solana_svm_timings::ExecuteTimings,
    solana_svm_transaction::svm_message::{SVMMessage, SVMStaticMessage},
    solana_syscalls::create_program_runtime_environment,
    solana_system_program::{get_system_account_kind, SystemAccountKind},
    solana_sysvar::Sysvar,
    solana_sysvar_id::SysvarId,
    solana_transaction::{
        sanitized::{MessageHash, SanitizedTransaction, MAX_TX_ACCOUNT_LOCKS},
        versioned::VersionedTransaction,
    },
    solana_transaction_context::{
        transaction::{ExecutionRecord, TransactionContext},
        IndexOfAccount,
    },
    solana_transaction_error::TransactionError,
    std::{cell::RefCell, path::Path, rc::Rc, sync::Arc},
    types::SimulatedTransactionInfo,
    utils::{
        construct_instructions_account,
        inner_instructions::inner_instructions_list_from_instruction_trace,
    },
    wincode::{DeserializeOwned, Serialize},
};

pub mod error;
pub mod types;

mod accounts_db;
mod callback;
#[cfg(feature = "sbpf-debugger")]
pub mod debugger;
pub mod features;
mod format_logs;
mod history;
#[cfg(feature = "precompiles")]
mod precompiles;
mod programs;
#[cfg(feature = "register-tracing")]
pub mod register_tracing;
#[cfg(feature = "register-tracing")]
pub mod register_tracing_filter;
mod utils;

/// Latest slot at which mainnet-beta activated a feature in [`MAINNET_ACTIVE_FEATURES`]; LiteSVM's default starting slot.
pub const MAINNET_DEFAULT_SLOT: u64 = {
    let mut max = 0;
    let mut i = 0;
    while i < MAINNET_ACTIVE_FEATURES.len() {
        if MAINNET_ACTIVE_FEATURES[i].1 > max {
            max = MAINNET_ACTIVE_FEATURES[i].1;
        }
        i += 1;
    }
    max
};

#[derive(Clone)]
pub struct LiteSVM {
    accounts: AccountsDb,
    airdrop_kp: [u8; 64],
    feature_set: FeatureSet,
    reserved_account_keys: ReservedAccountKeys,
    latest_blockhash: Hash,
    history: TransactionHistory,
    compute_budget: Option<ComputeBudget>,
    sigverify: bool,
    blockhash_check: bool,
    fee_structure: FeeStructure,
    log_bytes_limit: Option<usize>,
    custom_syscalls: Vec<(String, BuiltinFunctionRegisterer)>,
    epoch_total_stake: u64,
    epoch_vote_stakes: HashMap<Address, u64>,
    /// The callback which can be used to inspect invoke_context
    /// and extract low-level information such as bpf traces, transaction
    /// context, detailed timings, etc.
    #[cfg(feature = "invocation-inspect-callback")]
    invocation_inspect_callback: Arc<dyn InvocationInspectCallback>,
    /// Dictates whether or not register tracing was enabled.
    /// Provided as input to the invocation inspect callback for potential
    /// register trace consumption.
    #[cfg(feature = "invocation-inspect-callback")]
    enable_register_tracing: bool,
}

impl Default for LiteSVM {
    fn default() -> Self {
        let _enable_register_tracing = false;

        // Allow users to virtually get register tracing data without
        // doing any changes to their code provided `SBF_TRACE_DIR` is set.
        #[cfg(feature = "register-tracing")]
        let _enable_register_tracing = std::env::var("SBF_TRACE_DIR").is_ok();

        Self::new_inner(_enable_register_tracing)
    }
}

impl LiteSVM {
    fn new_inner(_enable_register_tracing: bool) -> Self {
        let feature_set = FeatureSet::default();

        #[allow(unused_mut)]
        let mut svm = Self {
            accounts: Default::default(),
            airdrop_kp: Keypair::new().to_bytes(),
            reserved_account_keys: Self::reserved_account_keys_for_feature_set(&feature_set),
            feature_set,
            latest_blockhash: create_blockhash(b"genesis"),
            history: TransactionHistory::new(),
            compute_budget: None,
            sigverify: false,
            blockhash_check: false,
            fee_structure: FeeStructure::default(),
            log_bytes_limit: Some(10_000),
            custom_syscalls: Vec::new(),
            epoch_total_stake: 0,
            epoch_vote_stakes: HashMap::new(),
            #[cfg(feature = "invocation-inspect-callback")]
            enable_register_tracing: _enable_register_tracing,
            #[cfg(feature = "invocation-inspect-callback")]
            invocation_inspect_callback: Arc::new(EmptyInvocationInspectCallback {}),
        };

        #[cfg(feature = "register-tracing")]
        if svm.enable_register_tracing {
            svm.invocation_inspect_callback = Arc::new(DefaultRegisterTracingCallback::default());
        }

        svm
    }

    fn into_basic(self) -> Self {
        let svm = self
            .with_mainnet_features()
            .with_builtins()
            .with_lamports(1_000_000u64.wrapping_mul(LAMPORTS_PER_SOL))
            .with_sysvars()
            .with_feature_accounts()
            .with_default_programs()
            .with_sigverify(true)
            .with_blockhash_check(true);

        #[cfg(feature = "precompiles")]
        let svm = svm.with_precompiles();

        svm
    }

    /// Creates the basic test environment.
    pub fn new() -> Self {
        LiteSVM::default().into_basic()
    }

    #[cfg(feature = "register-tracing")]
    /// Create a test environment with debugging features.
    ///
    /// This constructor allows enabling low-level VM debugging capabilities,
    /// such as register tracing, which are baked into program executables at
    /// load time and cannot be changed afterwards.
    ///
    /// When `enable_register_tracing` is `true`:
    /// - Programs are loaded with register tracing support
    /// - A default [`DefaultRegisterTracingCallback`] is installed
    /// - Trace data is written to `SBF_TRACE_DIR` (or `target/sbf/trace` by
    ///   default)
    pub fn new_debuggable(enable_register_tracing: bool) -> Self {
        Self::new_inner(enable_register_tracing).into_basic()
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_compute_budget(&mut self, compute_budget: ComputeBudget) {
        self.compute_budget = Some(compute_budget);
    }

    /// Sets the compute budget.
    pub fn with_compute_budget(mut self, compute_budget: ComputeBudget) -> Self {
        self.set_compute_budget(compute_budget);
        self
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_sigverify(&mut self, sigverify: bool) {
        self.sigverify = sigverify;
    }

    /// Enables or disables sigverify.
    pub fn with_sigverify(mut self, sigverify: bool) -> Self {
        self.set_sigverify(sigverify);
        self
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_blockhash_check(&mut self, check: bool) {
        self.blockhash_check = check;
    }

    /// Enables or disables the blockhash check.
    pub fn with_blockhash_check(mut self, check: bool) -> Self {
        self.set_blockhash_check(check);
        self
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_sysvars(&mut self) {
        self.set_sysvar(&Clock {
            slot: MAINNET_DEFAULT_SLOT,
            ..Default::default()
        });
        self.set_sysvar(&EpochRewards::default());
        self.set_sysvar(&EpochSchedule::default());
        #[allow(deprecated)]
        let fees = Fees::default();
        self.set_sysvar(&fees);
        self.set_sysvar(&LastRestartSlot::default());
        let latest_blockhash = self.latest_blockhash;
        #[allow(deprecated)]
        self.set_sysvar(&RecentBlockhashes::from_iter([IterItem(
            0,
            &latest_blockhash,
            fees.fee_calculator.lamports_per_signature,
        )]));

        // Rent account differs based off feature gating. Rent::default() already
        // carries the SIMD-0194 values (lamports_per_byte = 6960, threshold = 1.0);
        // without the feature, restore the legacy pre-SIMD-0194 representation
        // (lamports_per_byte_year = 3480, threshold = 2.0 — same minimum balance).
        #[allow(deprecated)]
        {
            let mut rent_account = Rent::default();
            if !self
                .feature_set
                .is_active(&agave_feature_set::deprecate_rent_exemption_threshold::id())
            {
                rent_account.exemption_threshold = 2.0f64.to_le_bytes();
                rent_account.lamports_per_byte = solana_rent::DEFAULT_LAMPORTS_PER_BYTE / 2;
            }
            self.set_sysvar(&rent_account);
        }
        self.set_sysvar(&SlotHashes::new(&[(
            self.accounts.sysvar_cache.get_clock().unwrap().slot,
            latest_blockhash,
        )]));
        self.set_sysvar(&SlotHistory::default());
        self.set_sysvar(&StakeHistory::default());

        // Initialize the deprecated StakeConfig account so it is available to programs
        // that still pass it as a transaction account (e.g. older DelegateStake callers).
        // Format: ConfigKeys header (8-byte u64 key count = 0) followed by
        // bincode-serialised Config::default().
        #[allow(deprecated)]
        {
            let mut data = [0; 17];
            data[8..16].copy_from_slice(&0.25_f64.to_le_bytes());
            data[16] = ((5 * u8::MAX as usize) / 100) as u8;
            let mut account = AccountSharedData::new(1, data.len(), &config_program::id());
            account.data_as_mut_slice().copy_from_slice(&data);
            self.accounts
                .add_account_no_checks(solana_sdk_ids::stake::config::id(), account);
        }
    }

    /// Includes the default sysvars.
    pub fn with_sysvars(mut self) -> Self {
        self.set_sysvars();
        self
    }

    /// Set the FeatureSet used by the VM instance.
    pub fn with_feature_set(mut self, feature_set: FeatureSet) -> Self {
        self.set_feature_set(feature_set);
        self
    }

    /// Returns a [`FeatureSet`] containing only the features currently
    /// activated on Solana mainnet-beta.
    ///
    /// The list of active features will need to be refreshed as mainnet
    /// activates new features. See also <https://www.simd.wtf/>.
    pub fn mainnet_feature_set() -> FeatureSet {
        let mut feature_set = FeatureSet::default();
        for (feature_id, activation_slot) in MAINNET_ACTIVE_FEATURES {
            feature_set.activate(feature_id, *activation_slot);
        }
        feature_set
    }

    /// Replace the feature set with one matching the features active on
    /// Solana mainnet-beta. See [`Self::mainnet_feature_set`].
    pub fn with_mainnet_features(self) -> Self {
        self.with_feature_set(Self::mainnet_feature_set())
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_feature_set(&mut self, feature_set: FeatureSet) {
        self.feature_set = feature_set;
        self.reserved_account_keys = Self::reserved_account_keys_for_feature_set(&self.feature_set);
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_feature_accounts(&mut self) {
        for (feature_id, activation_slot) in self.feature_set.active() {
            let feature_account = Feature {
                activated_at: Some(*activation_slot),
            };
            let lamports = self.minimum_balance_for_rent_exemption(Feature::size_of());
            let account = feature_gate::create_account(&feature_account, lamports);
            self.accounts.add_account_no_checks(*feature_id, account);
        }
    }

    /// Adds on-chain feature gate accounts corresponding to the currently active feature set.
    pub fn with_feature_accounts(mut self) -> Self {
        self.set_feature_accounts();
        self
    }

    fn reserved_account_keys_for_feature_set(feature_set: &FeatureSet) -> ReservedAccountKeys {
        let mut reserved_account_keys = ReservedAccountKeys::default();
        reserved_account_keys.update_active_set(feature_set);
        reserved_account_keys
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_builtins(&mut self) {
        let (lamports, rent_epoch) = solana_account::DUMMY_INHERITABLE_ACCOUNT_FIELDS;
        BUILTINS.iter().for_each(|builtint| {
            if builtint
                .enable_feature_id
                .is_none_or(|x| self.feature_set.is_active(&x))
            {
                let loaded_program = ProgramCacheEntry::new_builtin(0, builtint.register_fn);
                self.accounts
                    .programs_cache
                    .replenish(builtint.program_id, Arc::new(loaded_program));
                self.accounts.add_account_no_checks(
                    builtint.program_id,
                    AccountSharedData::from(Account {
                        lamports,
                        owner: native_loader::id(),
                        data: builtint.name.as_bytes().to_vec(),
                        executable: true,
                        rent_epoch,
                    }),
                );
            }
        });

        self.accounts.environments = self.create_program_runtime_environments();
    }

    /// Changes the default builtins.
    //
    // Use `with_feature_set` beforehand to change change what builtins are added.
    pub fn with_builtins(mut self) -> Self {
        self.set_builtins();
        self
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_lamports(&mut self, lamports: u64) {
        self.accounts.add_account_no_checks(
            Keypair::try_from(self.airdrop_kp.as_slice())
                .unwrap()
                .pubkey(),
            AccountSharedData::new(lamports, 0, &system_program::id()),
        );
    }

    /// Changes the initial lamports in LiteSVM's airdrop account.
    pub fn with_lamports(mut self, lamports: u64) -> Self {
        self.set_lamports(lamports);
        self
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_default_programs(&mut self) {
        load_default_programs(self);
    }

    /// Includes the standard SPL programs.
    pub fn with_default_programs(mut self) -> Self {
        self.set_default_programs();
        self
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_transaction_history(&mut self, capacity: usize) {
        self.history.set_capacity(capacity);
    }

    /// Changes the capacity of the transaction history.
    /// Set this to 0 to disable transaction history and allow duplicate transactions.
    pub fn with_transaction_history(mut self, capacity: usize) -> Self {
        self.set_transaction_history(capacity);
        self
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    fn set_log_bytes_limit(&mut self, limit: Option<usize>) {
        self.log_bytes_limit = limit;
    }

    /// Sets the maximum number of bytes collected from transaction logs. Pass `None` to remove the limit.
    pub fn with_log_bytes_limit(mut self, limit: Option<usize>) -> Self {
        self.set_log_bytes_limit(limit);
        self
    }

    #[cfg_attr(feature = "nodejs-internal", qualifiers(pub))]
    #[cfg(feature = "precompiles")]
    fn set_precompiles(&mut self) {
        load_precompiles(self);
    }

    /// Adds the standard precompiles to the VM.
    //
    // Use `with_feature_set` beforehand to change change what precompiles are added.
    #[cfg(feature = "precompiles")]
    pub fn with_precompiles(mut self) -> Self {
        self.set_precompiles();
        self
    }

    /// Returns minimum balance required to make an account with specified data length rent exempt.
    ///
    /// Returns `u64::MAX` for data lengths above the maximum permitted account
    /// size (10 MiB), for which no balance can be rent exempt.
    pub fn minimum_balance_for_rent_exemption(&self, data_len: usize) -> u64 {
        1.max(
            self.accounts
                .sysvar_cache
                .get_rent()
                .unwrap_or_default()
                .try_minimum_balance(data_len)
                .unwrap_or(u64::MAX),
        )
    }

    /// Returns all information associated with the account of the provided pubkey.
    pub fn get_account(&self, address: &Address) -> Option<Account> {
        self.accounts.get_account(address).map(Into::into)
    }

    /// Returns all accounts owned by the given program, together with their addresses.
    pub fn get_program_accounts(&self, program_id: &Address) -> Vec<(Address, Account)> {
        self.accounts
            .inner
            .iter()
            .filter(|(_, account)| account.owner() == program_id)
            .map(|(address, account)| (*address, account.clone().into()))
            .collect()
    }

    /// Sets all information associated with the account of the provided pubkey.
    pub fn set_account(&mut self, address: Address, data: Account) -> Result<(), LiteSVMError> {
        self.accounts.add_account(address, data.into())
    }

    /// Sets the active stake for `vote_account` returned by
    /// `sol_get_epoch_stake(vote_account)`.
    ///
    /// Updates the cluster total (`sol_get_epoch_stake(null)`) by replacing any
    /// previous stake for this vote: `total = total - previous + stake`, using
    /// checked arithmetic. Setting `stake` to `0` removes the vote from the map.
    ///
    /// Returns [`LiteSVMError::EpochStakeOverflow`] if the new total would
    /// overflow `u64`.
    ///
    /// # Examples
    ///
    /// ```
    /// use {litesvm::LiteSVM, solana_address::Address};
    ///
    /// let mut svm = LiteSVM::new();
    /// let vote = Address::new_unique();
    /// svm.set_epoch_stake(vote, 500).unwrap();
    /// svm.set_epoch_stake(vote, 200).unwrap(); // overwrite adjusts total
    /// assert_eq!(svm.epoch_stake(&vote), 200);
    /// assert_eq!(svm.epoch_total_stake(), 200);
    /// ```
    pub fn set_epoch_stake(
        &mut self,
        vote_account: Address,
        stake: u64,
    ) -> Result<(), LiteSVMError> {
        match self.epoch_vote_stakes.entry(vote_account) {
            Entry::Occupied(mut entry) => {
                let previous = *entry.get();
                self.epoch_total_stake = self
                    .epoch_total_stake
                    .checked_sub(previous)
                    .and_then(|total| total.checked_add(stake))
                    .ok_or(LiteSVMError::EpochStakeOverflow)?;
                if stake == 0 {
                    entry.remove();
                } else {
                    *entry.get_mut() = stake;
                }
            }
            Entry::Vacant(entry) => {
                if stake != 0 {
                    self.epoch_total_stake = self
                        .epoch_total_stake
                        .checked_add(stake)
                        .ok_or(LiteSVMError::EpochStakeOverflow)?;
                    entry.insert(stake);
                }
            }
        }
        Ok(())
    }

    /// Replaces all per-vote epoch stakes. The cluster total becomes the
    /// checked sum of `stakes` (zero entries are dropped).
    ///
    /// Returns [`LiteSVMError::EpochStakeOverflow`] if the sum overflows `u64`.
    pub fn set_epoch_stakes(
        &mut self,
        stakes: impl IntoIterator<Item = (Address, u64)>,
    ) -> Result<(), LiteSVMError> {
        let mut total = 0u64;
        let mut map = HashMap::new();
        for (vote_account, stake) in stakes {
            if stake == 0 {
                continue;
            }
            total = total
                .checked_add(stake)
                .ok_or(LiteSVMError::EpochStakeOverflow)?;
            map.insert(vote_account, stake);
        }
        self.epoch_vote_stakes = map;
        self.epoch_total_stake = total;
        Ok(())
    }

    /// Returns the total epoch stake (sum of all configured vote stakes).
    pub fn epoch_total_stake(&self) -> u64 {
        self.epoch_total_stake
    }

    /// Returns the configured epoch stake for `vote_account`, or `0` if unset.
    pub fn epoch_stake(&self, vote_account: &Address) -> u64 {
        self.epoch_vote_stakes
            .get(vote_account)
            .copied()
            .unwrap_or(0)
    }

    /// **⚠️ ADVANCED USE ONLY ⚠️**
    ///
    /// Returns a reference to the internal accounts database.
    ///
    /// This provides read-only access to the accounts database for advanced inspection.
    /// Use [`get_account`](LiteSVM::get_account) for normal account retrieval.
    ///
    /// # Examples
    ///
    /// ```rust,no_run
    /// use litesvm::LiteSVM;
    ///
    /// let svm = LiteSVM::new();
    ///
    /// // Read-only access to accounts database
    /// let accounts_db = svm.accounts_db();
    /// // ... inspect internal state if needed
    /// ```
    pub fn accounts_db(&self) -> &AccountsDb {
        &self.accounts
    }

    /// Gets the balance of the provided account pubkey.
    pub fn get_balance(&self, address: &Address) -> Option<u64> {
        self.accounts.get_account_ref(address).map(|x| x.lamports())
    }

    /// Gets the latest blockhash.
    pub fn latest_blockhash(&self) -> Hash {
        self.latest_blockhash
    }

    /// Sets the sysvar to the test environment.
    pub fn set_sysvar<T>(&mut self, sysvar: &T)
    where
        T: Sysvar + SysvarId + Serialize<Src = T>,
    {
        let len = if T::id() == SlotHashes::id() {
            solana_slot_hashes::SIZE
        } else {
            wincode::serialized_size(&sysvar).unwrap() as usize
        };
        let mut account = AccountSharedData::new(1, len, &solana_sdk_ids::sysvar::id());
        wincode::serialize_into(account.data_as_mut_slice(), sysvar).unwrap();
        self.accounts.add_account(T::id(), account).unwrap();
    }

    /// Gets a sysvar from the test environment.
    pub fn get_sysvar<T>(&self) -> T
    where
        T: Sysvar + SysvarId + DeserializeOwned<Dst = T>,
    {
        T::deserialize_from(self.accounts.get_account_ref(&T::id()).unwrap().data()).unwrap()
    }

    /// Gets a transaction from the transaction history.
    pub fn get_transaction(&self, signature: &Signature) -> Option<&TransactionResult> {
        self.history.get_transaction(signature)
    }

    /// Returns the pubkey of the internal airdrop account.
    pub fn airdrop_pubkey(&self) -> Address {
        Keypair::try_from(self.airdrop_kp.as_slice())
            .unwrap()
            .pubkey()
    }

    /// Airdrops the account with the lamports specified.
    pub fn airdrop(&mut self, address: &Address, lamports: u64) -> TransactionResult {
        let payer = Keypair::try_from(self.airdrop_kp.as_slice()).unwrap();
        let tx = VersionedTransaction::try_new(
            VersionedMessage::Legacy(Message::new_with_blockhash(
                &[solana_system_interface::instruction::transfer(
                    &payer.pubkey(),
                    address,
                    lamports,
                )],
                Some(&payer.pubkey()),
                &self.latest_blockhash,
            )),
            &[payer],
        )
        .unwrap();

        self.send_transaction(tx)
    }

    /// Adds a builtin program to the test environment.
    pub fn add_builtin(&mut self, program_id: Address, entrypoint: BuiltinFunctionRegisterer) {
        let builtin = ProgramCacheEntry::new_builtin(
            self.accounts
                .sysvar_cache
                .get_clock()
                .unwrap_or_default()
                .slot,
            entrypoint,
        );

        self.accounts
            .programs_cache
            .replenish(program_id, Arc::new(builtin));

        let mut account = AccountSharedData::new(1, 1, &native_loader::id());
        account.set_executable(true);
        self.accounts.add_account_no_checks(program_id, account);
    }

    /// Adds an SBF program to the test environment from the file specified.
    pub fn add_program_from_file(
        &mut self,
        program_id: impl Into<Address>,
        path: impl AsRef<Path>,
    ) -> Result<(), LiteSVMError> {
        let bytes = std::fs::read(path)?;
        self.add_program(program_id, &bytes)?;
        Ok(())
    }

    fn add_program_internal<const PREVERIFIED: bool>(
        &mut self,
        program_id: impl Into<Address>,
        program_bytes: &[u8],
        loader_id: &Address,
    ) -> Result<(), LiteSVMError> {
        let program_id = program_id.into();
        let current_slot = self
            .accounts
            .sysvar_cache
            .get_clock()
            .unwrap_or_default()
            .slot;

        if bpf_loader_upgradeable::check_id(loader_id) {
            let (programdata_address, _bump) =
                Address::find_program_address(&[program_id.as_ref()], loader_id);

            let programdata_metadata_len = UpgradeableLoaderState::size_of_programdata_metadata();
            let programdata_len = programdata_metadata_len + program_bytes.len();
            let mut programdata_data = vec![0u8; programdata_len];

            UpgradeableLoaderState::serialize_into(
                &mut programdata_data[..programdata_metadata_len],
                &UpgradeableLoaderState::ProgramData {
                    slot: current_slot,
                    upgrade_authority_address: None,
                },
            )
            .expect("UpgradeableLoaderState::ProgramData serialization should never fail");
            programdata_data[programdata_metadata_len..].copy_from_slice(program_bytes);

            let programdata_lamports = self.minimum_balance_for_rent_exemption(programdata_len);
            let mut programdata_account =
                AccountSharedData::new(programdata_lamports, programdata_len, loader_id);
            programdata_account.set_data_from_slice(&programdata_data);

            let program_account_data =
                UpgradeableLoaderState::serialize(&UpgradeableLoaderState::Program {
                    programdata_address,
                })
                .expect("UpgradeableLoaderState::Program serialization should never fail");

            let program_lamports =
                self.minimum_balance_for_rent_exemption(program_account_data.len());
            let mut program_account =
                AccountSharedData::new(program_lamports, program_account_data.len(), loader_id);
            program_account.set_executable(true);
            program_account.set_data_from_slice(&program_account_data);

            self.accounts
                .add_account_no_checks(programdata_address, programdata_account);
            self.accounts
                .add_account_no_checks(program_id, program_account);
        } else if bpf_loader::check_id(loader_id) || bpf_loader_deprecated::check_id(loader_id) {
            let program_len = program_bytes.len();
            let lamports = self.minimum_balance_for_rent_exemption(program_len);
            let mut account = AccountSharedData::new(lamports, program_len, loader_id);
            account.set_executable(true);
            account.set_data_from_slice(program_bytes);

            self.accounts.add_account_no_checks(program_id, account);
        } else {
            return Err(LiteSVMError::InvalidLoader(format!(
                "Unsupported loader: {loader_id}"
            )));
        }

        let program_runtime_for_deployment =
            self.accounts.environments.get_env_for_deployment().clone();
        let deployment_slot = visible_deployment_slot(current_slot);
        let loaded_program = if PREVERIFIED {
            load_preverified(
                loader_id,
                program_runtime_for_deployment,
                deployment_slot,
                program_bytes,
            )
        } else {
            ProgramCacheEntry::load(
                loader_id,
                program_runtime_for_deployment,
                deployment_slot,
                program_bytes,
                &mut LoadProgramMetrics::default(),
            )
        }
        .map_err(|e| LiteSVMError::ProgramLoad(e.to_string()))?;

        self.accounts
            .programs_cache
            .replenish(program_id, Arc::new(loaded_program));

        Ok(())
    }

    /// Adds an SBF program to the test environment.
    ///
    /// Uses `BPFLoaderUpgradeable` by default for the loader.
    pub fn add_program(
        &mut self,
        program_id: impl Into<Address>,
        program_bytes: &[u8],
    ) -> Result<(), LiteSVMError> {
        self.add_program_internal::<false>(program_id, program_bytes, &bpf_loader_upgradeable::id())
    }

    /// Adds an SBF program with a specific loader to match mainnet CU behavior.
    ///
    /// Use `bpf_loader::id()` for BPFLoader2, `bpf_loader_deprecated::id()` for BPFLoader1,
    /// or `bpf_loader_upgradeable::id()` for the upgradeable loader.
    pub fn add_program_with_loader(
        &mut self,
        program_id: impl Into<Address>,
        program_bytes: &[u8],
        loader_id: Address,
    ) -> Result<(), LiteSVMError> {
        self.add_program_internal::<false>(program_id, program_bytes, &loader_id)
    }

    /// Adds an SBF program that is known-good and already verified.
    pub(crate) fn add_program_preverified(
        &mut self,
        program_id: impl Into<Address>,
        program_bytes: &[u8],
        loader_id: &Address,
    ) -> Result<(), LiteSVMError> {
        self.add_program_internal::<true>(program_id, program_bytes, loader_id)
    }

    fn create_transaction_context(
        &self,
        compute_budget: ComputeBudget,
        accounts: Vec<(Address, AccountSharedData)>,
        number_of_top_level_instructions: usize,
    ) -> TransactionContext<'_> {
        TransactionContext::new(
            accounts,
            self.accounts
                .sysvar_cache
                .get_rent()
                .unwrap()
                .as_ref()
                .clone(),
            compute_budget.max_instruction_stack_depth,
            compute_budget.max_instruction_trace_length,
            number_of_top_level_instructions,
        )
    }

    fn sanitize_transaction_no_verify_inner(
        &self,
        tx: VersionedTransaction,
    ) -> Result<SanitizedTransaction, TransactionError> {
        let res = SanitizedTransaction::try_create(
            tx,
            MessageHash::Compute,
            Some(false),
            &self.accounts,
            &self.reserved_account_keys.active,
        );
        res.inspect_err(|_| {
            log::error!("Transaction sanitization failed");
        })
        .and_then(|tx| {
            SanitizedTransaction::validate_account_locks(
                tx.message(),
                get_transaction_account_lock_limit(self),
            )?;
            Ok(tx)
        })
    }

    fn sanitize_transaction_no_verify(
        &self,
        tx: VersionedTransaction,
    ) -> Result<SanitizedTransaction, ExecutionResult> {
        self.sanitize_transaction_no_verify_inner(tx)
            .map_err(|err| ExecutionResult {
                tx_result: Err(err),
                ..Default::default()
            })
    }

    fn sanitize_transaction(
        &self,
        tx: VersionedTransaction,
    ) -> Result<SanitizedTransaction, ExecutionResult> {
        self.sanitize_transaction_inner(tx)
            .map_err(|err| ExecutionResult {
                tx_result: Err(err),
                ..Default::default()
            })
    }

    fn sanitize_transaction_inner(
        &self,
        tx: VersionedTransaction,
    ) -> Result<SanitizedTransaction, TransactionError> {
        let tx = self.sanitize_transaction_no_verify_inner(tx)?;

        tx.verify()?;

        Ok(tx)
    }

    fn process_transaction<'a, 'b>(
        &'a self,
        tx: &'b SanitizedTransaction,
        tx_config: TransactionConfiguration,
        log_collector: Rc<RefCell<LogCollector>>,
    ) -> (
        Result<(), TransactionError>,
        u64,
        Option<TransactionContext<'b>>,
        u64,
        Option<Address>,
    )
    where
        'a: 'b,
    {
        let compute_budget = self.compute_budget.unwrap_or_else(|| ComputeBudget {
            compute_unit_limit: u64::from(tx_config.compute_unit_limit),
            heap_size: tx_config.updated_heap_bytes,
            ..ComputeBudget::new_with_defaults(
                self.feature_set
                    .is_active(&raise_cpi_nesting_limit_to_8::ID),
            )
        });
        let rent = self.accounts.sysvar_cache.get_rent().unwrap();
        let relax_post_exec_min_balance_check = self
            .feature_set
            .is_active(&agave_feature_set::relax_post_exec_min_balance_check::ID);
        let message = tx.message();
        let blockhash = message.recent_blockhash();
        //reload program cache
        let mut program_cache_for_tx_batch = self.accounts.programs_cache.clone();
        let mut accumulated_consume_units = 0;
        let account_keys = message.account_keys();
        let prioritization_fee = tx_config.priority_fee_lamports;
        let fee = solana_fee::calculate_fee(
            message,
            self.fee_structure.lamports_per_signature,
            prioritization_fee,
            FeeFeatures {},
        );
        let mut validated_fee_payer = false;
        let mut payer_key = None;

        let mut loaded_tx_data_size =
            LoadedTransactionDataSize::with_max_size(tx_config.loaded_accounts_data_size_limit);

        if let Err(e) = loaded_tx_data_size.increase_calculated_data_size(
            tx.message()
                .num_lookup_tables()
                .saturating_mul(ADDRESS_LOOKUP_TABLE_BASE_SIZE),
        ) {
            return (Err(e), accumulated_consume_units, None, fee, payer_key);
        }

        let mut pre_rent_state_infos = Vec::with_capacity(account_keys.len());
        let maybe_accounts = account_keys
            .iter()
            .enumerate()
            .map(|(i, key)| {
                let (loaded_size, account) = if solana_sdk_ids::sysvar::instructions::check_id(key)
                {
                    // according to agave code sysvar accounts are 0 loaded size:
                    // https://github.com/anza-xyz/agave/blob/v4.2.0/svm/src/account_loader.rs#L613-L618
                    (0, construct_instructions_account(message)?)
                } else {
                    let is_instruction_account =
                        SVMStaticMessage::is_instruction_account(message, i);
                    let (loaded_size, mut account) = if !is_instruction_account
                        && !message.is_writable(i)
                        && self.accounts.programs_cache.find(key).is_some()
                    {
                        // Optimization to skip loading of accounts which are only used as
                        // programs in top-level instructions and not passed as instruction accounts.
                        let account = self.accounts.get_account(key).unwrap();
                        (
                            TRANSACTION_ACCOUNT_BASE_SIZE.saturating_add(account.data().len()),
                            account,
                        )
                    } else {
                        self.accounts
                            .get_account(key)
                            .map(|acc| {
                                (
                                    TRANSACTION_ACCOUNT_BASE_SIZE.saturating_add(acc.data().len()),
                                    acc,
                                )
                            })
                            .unwrap_or_else(|| {
                                let mut default_account = AccountSharedData::default();
                                default_account.set_rent_epoch(u64::MAX);
                                (default_account.data().len(), default_account)
                            })
                    };
                    if message.is_writable(i)
                        && account.rent_epoch() != u64::MAX
                        && rent.is_exempt(account.lamports(), account.data().len())
                    {
                        account.set_rent_epoch(u64::MAX);
                    }
                    if !validated_fee_payer && (!message.is_invoked(i) || is_instruction_account) {
                        validate_fee_payer(
                            key,
                            &mut account,
                            i as IndexOfAccount,
                            &rent,
                            fee,
                            relax_post_exec_min_balance_check,
                        )?;
                        validated_fee_payer = true;
                        payer_key = Some(*key);
                    }
                    (loaded_size, account)
                };

                pre_rent_state_infos.push(RentStateInfo::new_pre_exec(
                    &rent,
                    account.lamports(),
                    account.data().len(),
                    *account.owner(),
                    relax_post_exec_min_balance_check,
                ));

                loaded_tx_data_size.increase_calculated_data_size(loaded_size)?;
                Ok((*key, account))
            })
            .collect::<solana_transaction_error::TransactionResult<Vec<_>>>();
        let accounts = match maybe_accounts {
            Ok(accs) => accs,
            Err(e) => {
                return (Err(e), accumulated_consume_units, None, fee, payer_key);
            }
        };
        if !validated_fee_payer {
            error!("Failed to validate fee payer");
            return (
                Err(TransactionError::AccountNotFound),
                accumulated_consume_units,
                None,
                fee,
                payer_key,
            );
        }
        let maybe_program_indices = tx
            .message()
            .instructions()
            .iter()
            .map(|c| {
                let program_index = c.program_id_index as usize;
                // This may never error, because the transaction is sanitized
                let (program_id, program_account) = accounts.get(program_index).unwrap();
                if native_loader::check_id(program_id) {
                    return Ok(program_index as IndexOfAccount);
                }
                if !program_account.executable() {
                    error!("Program account {program_id} is not executable.");
                    return Err(TransactionError::InvalidProgramForExecution);
                }

                let owner_id = program_account.owner();
                if native_loader::check_id(owner_id) {
                    return Ok(program_index as IndexOfAccount);
                }

                let owner_account = self.accounts.get_account(owner_id).unwrap();
                if !native_loader::check_id(owner_account.owner()) {
                    error!("Owner account {owner_id} is not owned by the native loader program.");
                    return Err(TransactionError::InvalidProgramForExecution);
                }
                if !owner_account.executable() {
                    error!("Owner account {owner_id} is not executable");
                    return Err(TransactionError::InvalidProgramForExecution);
                }
                Ok(program_index as IndexOfAccount)
            })
            .collect::<Result<Vec<u16>, TransactionError>>();

        match maybe_program_indices {
            // Only the invocation inspect callback consumes the indices.
            #[cfg_attr(not(feature = "invocation-inspect-callback"), allow(unused_variables))]
            Ok(program_indices) => {
                let mut context = self.create_transaction_context(
                    compute_budget,
                    accounts,
                    message.num_instructions(),
                );
                let feature_set = self.feature_set.runtime_features();
                let mut invoke_context = InvokeContext::new(
                    &mut context,
                    &mut program_cache_for_tx_batch,
                    EnvironmentConfig::new(
                        *blockhash,
                        self.fee_structure.lamports_per_signature,
                        false,
                        self,
                        &feature_set,
                        &self.accounts.environments,
                        &self.accounts.sysvar_cache,
                    ),
                    Some(log_collector),
                    compute_budget.to_budget(),
                    compute_budget.to_cost(),
                );

                #[cfg(feature = "invocation-inspect-callback")]
                self.invocation_inspect_callback.before_invocation(
                    self,
                    tx,
                    &program_indices,
                    &mut invoke_context,
                    self.enable_register_tracing,
                );

                let mut tx_result = invoke_context
                    .process_message(
                        message,
                        &mut ExecuteTimings::default(),
                        &mut accumulated_consume_units,
                    )
                    .map_err(|(index, err)| TransactionError::InstructionError(index, err));

                #[cfg(feature = "invocation-inspect-callback")]
                self.invocation_inspect_callback.after_invocation(
                    self,
                    tx,
                    &program_indices,
                    &invoke_context,
                    self.enable_register_tracing,
                );

                tx_result = tx_result
                    .and_then(|()| check_accounts_rent(tx, &context, &rent, &pre_rent_state_infos));

                (
                    tx_result,
                    accumulated_consume_units,
                    Some(context),
                    fee,
                    payer_key,
                )
            }
            Err(e) => (Err(e), accumulated_consume_units, None, fee, payer_key),
        }
    }

    fn execute_transaction_no_verify(
        &mut self,
        tx: VersionedTransaction,
        log_collector: Rc<RefCell<LogCollector>>,
    ) -> ExecutionResult {
        map_sanitize_result(self.sanitize_transaction_no_verify(tx), |s_tx| {
            self.execute_sanitized_transaction(&s_tx, log_collector)
        })
    }

    fn execute_transaction(
        &mut self,
        tx: VersionedTransaction,
        log_collector: Rc<RefCell<LogCollector>>,
    ) -> ExecutionResult {
        map_sanitize_result(self.sanitize_transaction(tx), |s_tx| {
            self.execute_sanitized_transaction(&s_tx, log_collector)
        })
    }

    fn execute_sanitized_transaction(
        &mut self,
        sanitized_tx: &SanitizedTransaction,
        log_collector: Rc<RefCell<LogCollector>>,
    ) -> ExecutionResult {
        let CheckAndProcessTransactionSuccess {
            core:
                CheckAndProcessTransactionSuccessCore {
                    result,
                    compute_units_consumed,
                    context,
                },
            fee,
            payer_key,
        } = match self.check_and_process_transaction(sanitized_tx, log_collector) {
            Ok(value) => value,
            Err(value) => return value,
        };
        if let Some(ctx) = context {
            let mut exec_result =
                execution_result_if_context(sanitized_tx, ctx, result, compute_units_consumed, fee);

            if let Some(payer) = payer_key.filter(|_| exec_result.tx_result.is_err()) {
                exec_result.tx_result = self
                    .accounts
                    .withdraw(&payer, fee)
                    .and(exec_result.tx_result);
            }
            exec_result
        } else {
            ExecutionResult {
                tx_result: result,
                compute_units_consumed,
                fee,
                ..Default::default()
            }
        }
    }

    fn execute_sanitized_transaction_readonly(
        &self,
        sanitized_tx: &SanitizedTransaction,
        log_collector: Rc<RefCell<LogCollector>>,
    ) -> ExecutionResult {
        let CheckAndProcessTransactionSuccess {
            core:
                CheckAndProcessTransactionSuccessCore {
                    result,
                    compute_units_consumed,
                    context,
                },
            fee,
            ..
        } = match self.check_and_process_transaction(sanitized_tx, log_collector) {
            Ok(value) => value,
            Err(value) => return value,
        };
        if let Some(ctx) = context {
            execution_result_if_context(sanitized_tx, ctx, result, compute_units_consumed, fee)
        } else {
            ExecutionResult {
                tx_result: result,
                compute_units_consumed,
                fee,
                ..Default::default()
            }
        }
    }

    fn check_and_process_transaction<'a, 'b>(
        &'a self,
        sanitized_tx: &'b SanitizedTransaction,
        log_collector: Rc<RefCell<LogCollector>>,
    ) -> Result<CheckAndProcessTransactionSuccess<'b>, ExecutionResult>
    where
        'a: 'b,
    {
        self.maybe_blockhash_check(sanitized_tx)?;
        let tx_config = get_transaction_config(sanitized_tx, &self.feature_set)?;
        self.maybe_history_check(sanitized_tx)?;
        let (result, compute_units_consumed, context, fee, payer_key) =
            self.process_transaction(sanitized_tx, tx_config, log_collector);
        #[cfg(target_arch = "x86_64")]
        unsafe {
            core::arch::asm!("emms", options(nomem, nostack, preserves_flags));
        }
        Ok(CheckAndProcessTransactionSuccess {
            core: {
                CheckAndProcessTransactionSuccessCore {
                    result,
                    compute_units_consumed,
                    context,
                }
            },
            fee,
            payer_key,
        })
    }

    fn maybe_history_check(
        &self,
        sanitized_tx: &SanitizedTransaction,
    ) -> Result<(), ExecutionResult> {
        if self.sigverify && self.history.check_transaction(sanitized_tx.signature()) {
            return Err(ExecutionResult {
                tx_result: Err(TransactionError::AlreadyProcessed),
                ..Default::default()
            });
        }
        Ok(())
    }

    fn maybe_blockhash_check(
        &self,
        sanitized_tx: &SanitizedTransaction,
    ) -> Result<(), ExecutionResult> {
        if self.blockhash_check {
            self.check_transaction_age(sanitized_tx)?;
        }
        Ok(())
    }

    fn execute_transaction_readonly(
        &self,
        tx: VersionedTransaction,
        log_collector: Rc<RefCell<LogCollector>>,
    ) -> ExecutionResult {
        map_sanitize_result(self.sanitize_transaction(tx), |s_tx| {
            self.execute_sanitized_transaction_readonly(&s_tx, log_collector)
        })
    }

    fn execute_transaction_no_verify_readonly(
        &self,
        tx: VersionedTransaction,
        log_collector: Rc<RefCell<LogCollector>>,
    ) -> ExecutionResult {
        map_sanitize_result(self.sanitize_transaction_no_verify(tx), |s_tx| {
            self.execute_sanitized_transaction_readonly(&s_tx, log_collector)
        })
    }

    /// Submits a signed transaction.
    pub fn send_transaction(&mut self, tx: impl Into<VersionedTransaction>) -> TransactionResult {
        let log_collector = LogCollector {
            bytes_limit: self.log_bytes_limit,
            ..Default::default()
        };
        let log_collector = Rc::new(RefCell::new(log_collector));
        let vtx: VersionedTransaction = tx.into();
        let ExecutionResult {
            post_accounts,
            tx_result,
            signature,
            compute_units_consumed,
            inner_instructions,
            return_data,
            included,
            fee,
        } = if self.sigverify {
            self.execute_transaction(vtx, log_collector.clone())
        } else {
            self.execute_transaction_no_verify(vtx, log_collector.clone())
        };
        let Ok(logs) = Rc::try_unwrap(log_collector).map(|lc| lc.into_inner().messages) else {
            unreachable!("Log collector should not be used after send_transaction returns")
        };
        let meta = TransactionMetadata {
            logs,
            inner_instructions,
            compute_units_consumed,
            return_data,
            signature,
            fee,
        };

        if let Err(tx_err) = tx_result {
            let err = TransactionResult::Err(FailedTransactionMetadata { err: tx_err, meta });
            if included && self.history.is_enabled() {
                self.history.add_new_transaction(signature, err.clone());
            }
            err
        } else {
            if self.history.is_enabled() {
                self.history
                    .add_new_transaction(signature, Ok(meta.clone()));
            }
            self.accounts
                .sync_accounts(post_accounts)
                .expect("It shouldn't be possible to write invalid sysvars in send_transaction.");

            TransactionResult::Ok(meta)
        }
    }

    /// Simulates a transaction.
    pub fn simulate_transaction(
        &self,
        tx: impl Into<VersionedTransaction>,
    ) -> Result<SimulatedTransactionInfo, FailedTransactionMetadata> {
        let log_collector = LogCollector {
            bytes_limit: self.log_bytes_limit,
            ..Default::default()
        };
        let log_collector = Rc::new(RefCell::new(log_collector));
        let ExecutionResult {
            post_accounts,
            tx_result,
            signature,
            compute_units_consumed,
            inner_instructions,
            return_data,
            fee,
            ..
        } = if self.sigverify {
            self.execute_transaction_readonly(tx.into(), log_collector.clone())
        } else {
            self.execute_transaction_no_verify_readonly(tx.into(), log_collector.clone())
        };
        let Ok(logs) = Rc::try_unwrap(log_collector).map(|lc| lc.into_inner().messages) else {
            unreachable!("Log collector should not be used after simulate_transaction returns")
        };
        let meta = TransactionMetadata {
            signature,
            logs,
            inner_instructions,
            compute_units_consumed,
            return_data,
            fee,
        };

        if let Err(tx_err) = tx_result {
            Err(FailedTransactionMetadata { err: tx_err, meta })
        } else {
            Ok(SimulatedTransactionInfo {
                meta,
                post_accounts,
            })
        }
    }

    /// Expires the current blockhash.
    pub fn expire_blockhash(&mut self) {
        self.latest_blockhash = create_blockhash(&self.latest_blockhash.to_bytes());
        #[allow(deprecated)]
        self.set_sysvar(&RecentBlockhashes::from_iter([IterItem(
            0,
            &self.latest_blockhash,
            self.fee_structure.lamports_per_signature,
        )]));
    }

    /// Warps the clock to the specified slot.
    pub fn warp_to_slot(&mut self, slot: u64) {
        let mut clock = self.get_sysvar::<Clock>();
        clock.slot = slot;
        self.set_sysvar(&clock);
    }

    /// Gets the current compute budget.
    pub fn get_compute_budget(&self) -> Option<ComputeBudget> {
        self.compute_budget
    }

    /// Returns whether transaction signature verification is enabled.
    pub fn get_sigverify(&self) -> bool {
        self.sigverify
    }

    fn check_transaction_age(&self, tx: &SanitizedTransaction) -> Result<(), ExecutionResult> {
        self.check_transaction_age_inner(tx)
            .map_err(|e| ExecutionResult {
                tx_result: Err(e),
                ..Default::default()
            })
    }

    fn check_transaction_age_inner(
        &self,
        tx: &SanitizedTransaction,
    ) -> solana_transaction_error::TransactionResult<()> {
        let recent_blockhash = tx.message().recent_blockhash();
        if recent_blockhash == &self.latest_blockhash
            || self.check_transaction_for_nonce(
                tx,
                &DurableNonce::from_blockhash(&self.latest_blockhash),
            )
        {
            Ok(())
        } else {
            log::error!(
                "Blockhash {} not found. Expected blockhash {}",
                recent_blockhash,
                self.latest_blockhash
            );
            Err(TransactionError::BlockhashNotFound)
        }
    }

    fn check_message_for_nonce(&self, message: &SanitizedMessage) -> bool {
        SVMMessage::get_durable_nonce(message)
            .and_then(|nonce_address| self.accounts.get_account_ref(nonce_address))
            .and_then(|nonce_account| {
                solana_nonce_account::verify_nonce_account(
                    nonce_account,
                    message.recent_blockhash(),
                )
            })
            .is_some_and(|nonce_data| {
                SVMStaticMessage::get_ix_signers(message, NONCED_TX_MARKER_IX_INDEX as usize)
                    .any(|signer| signer == &nonce_data.authority)
            })
    }

    fn check_transaction_for_nonce(
        &self,
        tx: &SanitizedTransaction,
        next_durable_nonce: &DurableNonce,
    ) -> bool {
        let nonce_is_advanceable = tx.message().recent_blockhash() != next_durable_nonce.as_hash();
        nonce_is_advanceable && self.check_message_for_nonce(tx.message())
    }

    #[cfg(feature = "invocation-inspect-callback")]
    pub fn set_invocation_inspect_callback<C: InvocationInspectCallback + 'static>(
        &mut self,
        callback: C,
    ) {
        self.invocation_inspect_callback = Arc::new(callback);
    }

    /// Registers a custom syscall in both program runtime environments.
    ///
    /// **Must be called before loading programs** (`with_default_programs()`,
    /// `add_program`, ...): program cache entries capture the runtime
    /// environment at load time, so programs loaded earlier will not see the
    /// syscall. Note that `LiteSVM::new()` already loads the default programs —
    /// start from `LiteSVM::default()` and build up manually when using custom
    /// syscalls.
    ///
    /// Panics if registration fails. This is intentional — a misconfigured
    /// syscall should fail loudly rather than silently.
    pub fn with_custom_syscall(mut self, name: &str, syscall: BuiltinFunctionRegisterer) -> Self {
        self.custom_syscalls.push((name.to_owned(), syscall));
        self.accounts.environments = self.create_program_runtime_environments();
        self
    }

    fn create_program_runtime_environments(&self) -> ProgramRuntimeEnvironments {
        #[cfg(feature = "register-tracing")]
        let debugging_features = self.enable_register_tracing;
        #[cfg(not(feature = "register-tracing"))]
        let debugging_features = false;
        let compute_budget = self
            .compute_budget
            .unwrap_or(ComputeBudget::new_with_defaults(
                self.feature_set
                    .is_active(&raise_cpi_nesting_limit_to_8::ID),
            ));
        let env = create_program_runtime_environment(
            &self.feature_set.runtime_features(),
            &compute_budget.to_budget(),
            false,
            debugging_features,
        )
        .unwrap();
        let env = self.register_custom_syscalls(env);
        ProgramRuntimeEnvironments::new(env.clone(), env)
    }

    fn register_custom_syscalls(
        &self,
        env: ProgramRuntimeEnvironment,
    ) -> ProgramRuntimeEnvironment {
        if self.custom_syscalls.is_empty() {
            return env;
        }

        let mut program = BuiltinProgram::new_loader((*env).get_config().clone());
        for (_key, (name, value)) in (*env).get_function_registry().iter() {
            program
                .register_function(
                    std::str::from_utf8(name).expect("syscall names are valid utf-8"),
                    value,
                )
                .unwrap();
        }
        for (name, syscall) in &self.custom_syscalls {
            syscall(&mut program, name)
                .unwrap_or_else(|e| panic!("failed to register syscall '{name}': {e}"));
        }

        ProgramRuntimeEnvironment::from(program)
    }

    // ── persistence-internal: getters ──────────────────────────────────

    #[cfg(feature = "persistence-internal")]
    pub fn airdrop_keypair_bytes(&self) -> &[u8; 64] {
        &self.airdrop_kp
    }

    #[cfg(feature = "persistence-internal")]
    pub fn get_blockhash_check(&self) -> bool {
        self.blockhash_check
    }

    #[cfg(feature = "persistence-internal")]
    pub fn get_fee_structure(&self) -> &FeeStructure {
        &self.fee_structure
    }

    #[cfg(feature = "persistence-internal")]
    pub fn get_log_bytes_limit(&self) -> Option<usize> {
        self.log_bytes_limit
    }

    #[cfg(feature = "persistence-internal")]
    pub fn get_feature_set_ref(&self) -> &FeatureSet {
        &self.feature_set
    }

    #[cfg(feature = "persistence-internal")]
    pub fn transaction_history_entries(&self) -> &IndexMap<Signature, TransactionResult> {
        self.history.entries()
    }

    #[cfg(feature = "persistence-internal")]
    pub fn transaction_history_capacity(&self) -> usize {
        self.history.capacity()
    }

    #[cfg(feature = "persistence-internal")]
    pub fn epoch_vote_stakes(&self) -> impl Iterator<Item = (&Address, &u64)> {
        self.epoch_vote_stakes.iter()
    }

    // ── persistence-internal: setters ──────────────────────────────────

    #[cfg(feature = "persistence-internal")]
    pub fn set_latest_blockhash(&mut self, hash: Hash) {
        self.latest_blockhash = hash;
    }

    #[cfg(feature = "persistence-internal")]
    pub fn set_airdrop_keypair(&mut self, kp: [u8; 64]) {
        self.airdrop_kp = kp;
    }

    #[cfg(feature = "persistence-internal")]
    pub fn set_account_no_checks(&mut self, pubkey: Address, account: AccountSharedData) {
        self.accounts.add_account_no_checks(pubkey, account);
    }

    #[cfg(feature = "persistence-internal")]
    pub fn restore_transaction_history(
        &mut self,
        entries: IndexMap<Signature, TransactionResult>,
        capacity: usize,
    ) {
        self.history = TransactionHistory::from_entries(entries, capacity);
    }

    #[cfg(feature = "persistence-internal")]
    pub fn set_fee_structure(&mut self, fee_structure: FeeStructure) {
        self.fee_structure = fee_structure;
    }

    // ── persistence-internal: cache rebuild ────────────────────────────

    /// Rebuilds all derived caches after bulk account insertion.
    ///
    /// Must be called after restoring accounts via `set_account_no_checks`.
    /// Order matters: environments first, then sysvars, then BPF programs.
    #[cfg(feature = "persistence-internal")]
    pub fn rebuild_caches(&mut self) -> Result<(), LiteSVMError> {
        self.reserved_account_keys = Self::reserved_account_keys_for_feature_set(&self.feature_set);
        self.set_builtins();
        self.accounts.rebuild_sysvar_cache();
        self.accounts.load_all_existing_programs()?;
        Ok(())
    }
}

struct CheckAndProcessTransactionSuccessCore<'ix_data> {
    result: Result<(), TransactionError>,
    compute_units_consumed: u64,
    context: Option<TransactionContext<'ix_data>>,
}

struct CheckAndProcessTransactionSuccess<'ix_data> {
    core: CheckAndProcessTransactionSuccessCore<'ix_data>,
    fee: u64,
    payer_key: Option<Address>,
}

fn execution_result_if_context(
    sanitized_tx: &SanitizedTransaction,
    ctx: TransactionContext,
    result: Result<(), TransactionError>,
    compute_units_consumed: u64,
    fee: u64,
) -> ExecutionResult {
    let (signature, return_data, inner_instructions, post_accounts) =
        execute_tx_helper(sanitized_tx, ctx);
    ExecutionResult {
        tx_result: result,
        signature,
        post_accounts,
        inner_instructions,
        compute_units_consumed,
        return_data,
        included: true,
        fee,
    }
}

fn execute_tx_helper(
    sanitized_tx: &SanitizedTransaction,
    ctx: TransactionContext,
) -> (
    Signature,
    solana_transaction_context::transaction::TransactionReturnData,
    InnerInstructionsList,
    Vec<(Address, AccountSharedData)>,
) {
    let signature = sanitized_tx.signature().to_owned();
    let inner_instructions = inner_instructions_list_from_instruction_trace(&ctx);
    let ExecutionRecord {
        accounts,
        return_data,
        touched_flags: _,
        accounts_resize_delta: _,
    } = ctx.into();
    let msg = sanitized_tx.message();
    let post_accounts = accounts
        .into_iter()
        .enumerate()
        .filter_map(|(idx, pair)| msg.is_writable(idx).then_some(pair))
        .collect();
    (signature, return_data, inner_instructions, post_accounts)
}

fn get_transaction_config(
    sanitized_tx: &SanitizedTransaction,
    feature_set: &FeatureSet,
) -> Result<TransactionConfiguration, ExecutionResult> {
    TransactionConfiguration::try_from_sanitized_message(sanitized_tx.message(), feature_set)
        .map_err(|e| ExecutionResult {
            tx_result: Err(e),
            ..Default::default()
        })
}

/// Get the max number of accounts that a transaction may lock in this block
fn get_transaction_account_lock_limit(svm: &LiteSVM) -> usize {
    if svm
        .feature_set
        .is_active(&agave_feature_set::increase_tx_account_lock_limit::id())
    {
        MAX_TX_ACCOUNT_LOCKS
    } else {
        64
    }
}

fn check_accounts_rent(
    tx: &SanitizedTransaction,
    context: &TransactionContext,
    rent: &Rent,
    pre_rent_state_infos: &[RentStateInfo],
) -> Result<(), TransactionError> {
    let message = tx.message();
    for (index, pre_rent_state_info) in pre_rent_state_infos.iter().enumerate() {
        if message.is_writable(index) {
            let account = context
                .accounts()
                .try_borrow(index as IndexOfAccount)
                .map_err(|err| TransactionError::InstructionError(index as u8, err))?;

            let pubkey = context
                .get_key_of_account_at_index(index as IndexOfAccount)
                .map_err(|err| TransactionError::InstructionError(index as u8, err))?;

            let post_rent_state = pre_rent_state_info.post_exec_rent_state(
                rent,
                account.lamports(),
                account.data().len(),
                *account.owner(),
            );

            check_rent_state_with_account(
                pre_rent_state_info.rent_state(),
                &post_rent_state,
                pubkey,
                index as IndexOfAccount,
            )?;
        }
    }
    Ok(())
}

/// Lighter version of the one in the solana-svm crate.
///
/// Check whether the payer_account is capable of paying the fee. The
/// side effect is to subtract the fee amount from the payer_account
/// balance of lamports. If the payer_acount is not able to pay the
/// fee a specific error is returned.
fn validate_fee_payer(
    payer_address: &Address,
    payer_account: &mut AccountSharedData,
    payer_index: IndexOfAccount,
    rent: &Rent,
    fee: u64,
    relax_post_exec_min_balance_check: bool,
) -> solana_transaction_error::TransactionResult<()> {
    if payer_account.lamports() == 0 {
        error!("Payer account {payer_address} not found.");
        return Err(TransactionError::AccountNotFound);
    }
    let system_account_kind = get_system_account_kind(payer_account).ok_or_else(|| {
        error!("Payer account {payer_address} is not a system account");
        TransactionError::InvalidAccountForFee
    })?;
    let min_balance = match system_account_kind {
        SystemAccountKind::System => 0,
        SystemAccountKind::Nonce => {
            // Should we ever allow a fees charge to zero a nonce account's
            // balance. The state MUST be set to uninitialized in that case
            rent.minimum_balance(solana_nonce::state::State::size())
        }
    };

    let payer_lamports = payer_account.lamports();

    payer_lamports
        .checked_sub(min_balance)
        .and_then(|v| v.checked_sub(fee))
        .ok_or_else(|| {
            error!(
                "Payer account {payer_address} has insufficient lamports for fee. Payer lamports: \
                {payer_lamports} min_balance: {min_balance} fee: {fee}"
            );
            TransactionError::InsufficientFundsForFee
        })?;

    let pre_rent_state_info = RentStateInfo::new_pre_exec(
        rent,
        payer_lamports,
        payer_account.data().len(),
        *payer_account.owner(),
        relax_post_exec_min_balance_check,
    );
    // we already checked above if we have sufficient balance so this should never error.
    payer_account.checked_sub_lamports(fee).unwrap();

    let post_rent_state = pre_rent_state_info.post_exec_rent_state(
        rent,
        payer_account.lamports(),
        payer_account.data().len(),
        *payer_account.owner(),
    );
    check_rent_state_with_account(
        pre_rent_state_info.rent_state(),
        &post_rent_state,
        payer_address,
        payer_index,
    )
}

fn map_sanitize_result<F>(
    res: Result<SanitizedTransaction, ExecutionResult>,
    op: F,
) -> ExecutionResult
where
    F: FnOnce(SanitizedTransaction) -> ExecutionResult,
{
    match res {
        Ok(s_tx) => op(s_tx),
        Err(e) => e,
    }
}

#[cfg(feature = "invocation-inspect-callback")]
pub trait InvocationInspectCallback: Send + Sync {
    fn before_invocation(
        &self,
        svm: &LiteSVM,
        tx: &SanitizedTransaction,
        program_indices: &[IndexOfAccount],
        invoke_context: &mut InvokeContext,
        enable_register_tracing: bool,
    );

    fn after_invocation(
        &self,
        svm: &LiteSVM,
        tx: &SanitizedTransaction,
        program_indices: &[IndexOfAccount],
        invoke_context: &InvokeContext,
        enable_register_tracing: bool,
    );
}

#[cfg(feature = "invocation-inspect-callback")]
pub struct EmptyInvocationInspectCallback;

#[cfg(feature = "invocation-inspect-callback")]
impl InvocationInspectCallback for EmptyInvocationInspectCallback {
    fn before_invocation(
        &self,
        _: &LiteSVM,
        _: &SanitizedTransaction,
        _: &[IndexOfAccount],
        _: &mut InvokeContext,
        _enable_register_tracing: bool,
    ) {
    }

    fn after_invocation(
        &self,
        _: &LiteSVM,
        _: &SanitizedTransaction,
        _: &[IndexOfAccount],
        _: &InvokeContext,
        _enable_register_tracing: bool,
    ) {
    }
}

#[cfg(test)]
mod tests {
    use {
        super::*,
        solana_instruction::{account_meta::AccountMeta, Instruction},
        solana_message::{Message, VersionedMessage},
    };

    #[test]
    fn sysvar_accounts_are_demoted_to_readonly() {
        let payer = Keypair::new();
        let svm = LiteSVM::new();
        let rent_key = solana_sdk_ids::sysvar::rent::id();
        let ix = Instruction {
            program_id: solana_sdk_ids::system_program::id(),
            accounts: vec![AccountMeta {
                pubkey: rent_key,
                is_signer: false,
                is_writable: true,
            }],
            data: vec![],
        };
        let message = Message::new(&[ix], Some(&payer.pubkey()));
        let tx =
            VersionedTransaction::try_new(VersionedMessage::Legacy(message), &[&payer]).unwrap();
        let sanitized = svm.sanitize_transaction_no_verify_inner(tx).unwrap();

        assert!(!sanitized.message().is_writable(1));
    }

    /// Writing the clock must refresh the whole sysvar cache — the new clock
    /// included — without consulting a copy of the account store.
    #[test]
    fn setting_clock_refreshes_sysvar_cache() {
        let mut svm = LiteSVM::new();
        // An unrelated account, to make sure the cache is filled from the live
        // store rather than a snapshot taken before it was added.
        svm.set_account(
            Address::new_unique(),
            Account {
                lamports: 1,
                data: vec![],
                owner: solana_sdk_ids::system_program::ID,
                executable: false,
                rent_epoch: 0,
            },
        )
        .unwrap();

        let mut clock = svm.get_sysvar::<Clock>();
        clock.slot = 1234;
        clock.unix_timestamp = 5678;
        svm.set_sysvar(&clock);

        let cache = &svm.accounts.sysvar_cache;
        let cached_clock = cache.get_clock().unwrap();
        assert_eq!(cached_clock.slot, 1234);
        assert_eq!(cached_clock.unix_timestamp, 5678);
        assert_eq!(svm.get_sysvar::<Clock>().slot, 1234);

        // The other sysvars must survive the cache reset.
        assert!(cache.get_rent().is_ok());
        assert!(cache.get_epoch_schedule().is_ok());
        assert!(cache.get_epoch_rewards().is_ok());
        assert!(cache.get_slot_hashes().is_ok());
        assert!(cache.get_stake_history().is_ok());
        assert!(cache.get_last_restart_slot().is_ok());
    }
}
